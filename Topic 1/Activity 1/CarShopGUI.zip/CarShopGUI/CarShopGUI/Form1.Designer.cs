﻿namespace CarShopGUI
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.addACarGroupBox = new System.Windows.Forms.GroupBox();
            this.colorTextBox = new System.Windows.Forms.TextBox();
            this.yearTextBox = new System.Windows.Forms.TextBox();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.modelTextBox = new System.Windows.Forms.TextBox();
            this.makeTextBox = new System.Windows.Forms.TextBox();
            this.colorLabel = new System.Windows.Forms.Label();
            this.yearLabel = new System.Windows.Forms.Label();
            this.priceLabel = new System.Windows.Forms.Label();
            this.modelLabel = new System.Windows.Forms.Label();
            this.makeLabel = new System.Windows.Forms.Label();
            this.addCarBtn = new System.Windows.Forms.Button();
            this.carInventoryGroupBox = new System.Windows.Forms.GroupBox();
            this.carInventoryListBox = new System.Windows.Forms.ListBox();
            this.addToCartBtn = new System.Windows.Forms.Button();
            this.shoppingCartGroupBox = new System.Windows.Forms.GroupBox();
            this.shoppingCartListBox = new System.Windows.Forms.ListBox();
            this.checkoutBtn = new System.Windows.Forms.Button();
            this.cartTotalLabel = new System.Windows.Forms.Label();
            this.addACarGroupBox.SuspendLayout();
            this.carInventoryGroupBox.SuspendLayout();
            this.shoppingCartGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // addACarGroupBox
            // 
            this.addACarGroupBox.Controls.Add(this.colorTextBox);
            this.addACarGroupBox.Controls.Add(this.yearTextBox);
            this.addACarGroupBox.Controls.Add(this.priceTextBox);
            this.addACarGroupBox.Controls.Add(this.modelTextBox);
            this.addACarGroupBox.Controls.Add(this.makeTextBox);
            this.addACarGroupBox.Controls.Add(this.colorLabel);
            this.addACarGroupBox.Controls.Add(this.yearLabel);
            this.addACarGroupBox.Controls.Add(this.priceLabel);
            this.addACarGroupBox.Controls.Add(this.modelLabel);
            this.addACarGroupBox.Controls.Add(this.makeLabel);
            this.addACarGroupBox.Location = new System.Drawing.Point(12, 49);
            this.addACarGroupBox.Name = "addACarGroupBox";
            this.addACarGroupBox.Size = new System.Drawing.Size(200, 171);
            this.addACarGroupBox.TabIndex = 0;
            this.addACarGroupBox.TabStop = false;
            this.addACarGroupBox.Text = "Add A Car";
            // 
            // colorTextBox
            // 
            this.colorTextBox.Location = new System.Drawing.Point(59, 128);
            this.colorTextBox.Name = "colorTextBox";
            this.colorTextBox.Size = new System.Drawing.Size(100, 23);
            this.colorTextBox.TabIndex = 8;
            // 
            // yearTextBox
            // 
            this.yearTextBox.Location = new System.Drawing.Point(59, 103);
            this.yearTextBox.Name = "yearTextBox";
            this.yearTextBox.Size = new System.Drawing.Size(100, 23);
            this.yearTextBox.TabIndex = 7;
            // 
            // priceTextBox
            // 
            this.priceTextBox.Location = new System.Drawing.Point(59, 79);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(100, 23);
            this.priceTextBox.TabIndex = 6;
            // 
            // modelTextBox
            // 
            this.modelTextBox.Location = new System.Drawing.Point(59, 55);
            this.modelTextBox.Name = "modelTextBox";
            this.modelTextBox.Size = new System.Drawing.Size(100, 23);
            this.modelTextBox.TabIndex = 1;
            // 
            // makeTextBox
            // 
            this.makeTextBox.Location = new System.Drawing.Point(59, 31);
            this.makeTextBox.Name = "makeTextBox";
            this.makeTextBox.Size = new System.Drawing.Size(100, 23);
            this.makeTextBox.TabIndex = 5;
            // 
            // colorLabel
            // 
            this.colorLabel.AutoSize = true;
            this.colorLabel.Location = new System.Drawing.Point(6, 136);
            this.colorLabel.Name = "colorLabel";
            this.colorLabel.Size = new System.Drawing.Size(39, 15);
            this.colorLabel.TabIndex = 4;
            this.colorLabel.Text = "Color:";
            // 
            // yearLabel
            // 
            this.yearLabel.AutoSize = true;
            this.yearLabel.Location = new System.Drawing.Point(6, 111);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(32, 15);
            this.yearLabel.TabIndex = 3;
            this.yearLabel.Text = "Year:";
            // 
            // priceLabel
            // 
            this.priceLabel.AutoSize = true;
            this.priceLabel.Location = new System.Drawing.Point(6, 87);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(36, 15);
            this.priceLabel.TabIndex = 2;
            this.priceLabel.Text = "Price:";
            // 
            // modelLabel
            // 
            this.modelLabel.AutoSize = true;
            this.modelLabel.Location = new System.Drawing.Point(6, 63);
            this.modelLabel.Name = "modelLabel";
            this.modelLabel.Size = new System.Drawing.Size(44, 15);
            this.modelLabel.TabIndex = 1;
            this.modelLabel.Text = "Model:";
            // 
            // makeLabel
            // 
            this.makeLabel.AutoSize = true;
            this.makeLabel.Location = new System.Drawing.Point(6, 39);
            this.makeLabel.Name = "makeLabel";
            this.makeLabel.Size = new System.Drawing.Size(39, 15);
            this.makeLabel.TabIndex = 0;
            this.makeLabel.Text = "Make:";
            // 
            // addCarBtn
            // 
            this.addCarBtn.Location = new System.Drawing.Point(71, 226);
            this.addCarBtn.Name = "addCarBtn";
            this.addCarBtn.Size = new System.Drawing.Size(75, 23);
            this.addCarBtn.TabIndex = 1;
            this.addCarBtn.Text = "Add Car";
            this.addCarBtn.UseVisualStyleBackColor = true;
            this.addCarBtn.Click += new System.EventHandler(this.addCarBtn_Click);
            // 
            // carInventoryGroupBox
            // 
            this.carInventoryGroupBox.Controls.Add(this.carInventoryListBox);
            this.carInventoryGroupBox.Location = new System.Drawing.Point(227, 49);
            this.carInventoryGroupBox.Name = "carInventoryGroupBox";
            this.carInventoryGroupBox.Size = new System.Drawing.Size(466, 138);
            this.carInventoryGroupBox.TabIndex = 2;
            this.carInventoryGroupBox.TabStop = false;
            this.carInventoryGroupBox.Text = "Car Inventory";
            // 
            // carInventoryListBox
            // 
            this.carInventoryListBox.FormattingEnabled = true;
            this.carInventoryListBox.ItemHeight = 15;
            this.carInventoryListBox.Location = new System.Drawing.Point(6, 22);
            this.carInventoryListBox.Name = "carInventoryListBox";
            this.carInventoryListBox.Size = new System.Drawing.Size(454, 109);
            this.carInventoryListBox.TabIndex = 0;
            // 
            // addToCartBtn
            // 
            this.addToCartBtn.Location = new System.Drawing.Point(610, 206);
            this.addToCartBtn.Name = "addToCartBtn";
            this.addToCartBtn.Size = new System.Drawing.Size(83, 28);
            this.addToCartBtn.TabIndex = 3;
            this.addToCartBtn.Text = "Add to Cart";
            this.addToCartBtn.UseVisualStyleBackColor = true;
            this.addToCartBtn.Click += new System.EventHandler(this.addToCartBtn_Click);
            // 
            // shoppingCartGroupBox
            // 
            this.shoppingCartGroupBox.Controls.Add(this.shoppingCartListBox);
            this.shoppingCartGroupBox.Location = new System.Drawing.Point(227, 252);
            this.shoppingCartGroupBox.Name = "shoppingCartGroupBox";
            this.shoppingCartGroupBox.Size = new System.Drawing.Size(466, 188);
            this.shoppingCartGroupBox.TabIndex = 4;
            this.shoppingCartGroupBox.TabStop = false;
            this.shoppingCartGroupBox.Text = "Shopping Cart";
            // 
            // shoppingCartListBox
            // 
            this.shoppingCartListBox.FormattingEnabled = true;
            this.shoppingCartListBox.ItemHeight = 15;
            this.shoppingCartListBox.Location = new System.Drawing.Point(6, 22);
            this.shoppingCartListBox.Name = "shoppingCartListBox";
            this.shoppingCartListBox.Size = new System.Drawing.Size(454, 154);
            this.shoppingCartListBox.TabIndex = 0;
            // 
            // checkoutBtn
            // 
            this.checkoutBtn.Location = new System.Drawing.Point(618, 459);
            this.checkoutBtn.Name = "checkoutBtn";
            this.checkoutBtn.Size = new System.Drawing.Size(75, 23);
            this.checkoutBtn.TabIndex = 5;
            this.checkoutBtn.Text = "Checkout";
            this.checkoutBtn.UseVisualStyleBackColor = true;
            this.checkoutBtn.Click += new System.EventHandler(this.checkoutBtn_Click);
            // 
            // cartTotalLabel
            // 
            this.cartTotalLabel.AutoSize = true;
            this.cartTotalLabel.Location = new System.Drawing.Point(538, 520);
            this.cartTotalLabel.Name = "cartTotalLabel";
            this.cartTotalLabel.Size = new System.Drawing.Size(60, 15);
            this.cartTotalLabel.TabIndex = 6;
            this.cartTotalLabel.Text = "Cart Total:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(723, 556);
            this.Controls.Add(this.cartTotalLabel);
            this.Controls.Add(this.checkoutBtn);
            this.Controls.Add(this.shoppingCartGroupBox);
            this.Controls.Add(this.addToCartBtn);
            this.Controls.Add(this.carInventoryGroupBox);
            this.Controls.Add(this.addCarBtn);
            this.Controls.Add(this.addACarGroupBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Car Store";
            this.addACarGroupBox.ResumeLayout(false);
            this.addACarGroupBox.PerformLayout();
            this.carInventoryGroupBox.ResumeLayout(false);
            this.shoppingCartGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox addACarGroupBox;
        private TextBox colorTextBox;
        private TextBox yearTextBox;
        private TextBox priceTextBox;
        private TextBox modelTextBox;
        private TextBox makeTextBox;
        private Label colorLabel;
        private Label yearLabel;
        private Label priceLabel;
        private Label modelLabel;
        private Label makeLabel;
        private Button addCarBtn;
        private GroupBox carInventoryGroupBox;
        private ListBox carInventoryListBox;
        private Button addToCartBtn;
        private GroupBox shoppingCartGroupBox;
        private ListBox shoppingCartListBox;
        private Button checkoutBtn;
        private Label cartTotalLabel;
    }
}