using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Completed with examples and code
//for CST-250
//Ryan Coon
//November 6, 2022
namespace CarShopGUI
{
    public partial class Form1 : Form
    {
        Store store = new Store();
        DateTime moment = new DateTime();
        BindingSource carListBinding = new BindingSource();
        BindingSource shoppingListBinding = new BindingSource();

        public Form1()
        {
            OnLoad();
            InitializeComponent();
            SetBindings();


        }

        private void OnLoad()
        {
            store.CarList.Add(new Car("Mazda", "Miata", 18000, 1999, "Red"));
            store.CarList.Add(new Car("Ford", "Mustang GT", 28000, 2019, "Green"));
            store.CarList.Add(new Car("Jeep", "Grand Cherokee", 48000, 2020, "Blue"));
            store.CarList.Add(new Car("Dodge", "Ram 1500", 38000, 2018, "Silver"));
            store.CarList.Add(new Car("Acura", "Integra", 17000, 2019, "Yellow"));
            store.CarList.Add(new Car("Chevrolet", "Corvette", 16000, 1999, "Silver"));
        }

        private void SetBindings()
        {
            carListBinding.DataSource = store.CarList;
            carInventoryListBox.DataSource = carListBinding;
            carInventoryListBox.DisplayMember = "Display";
            carInventoryListBox.ValueMember = "Display";
            shoppingListBinding.DataSource = store.ShoppingList;
            shoppingCartListBox.DataSource = shoppingListBinding;
            shoppingCartListBox.DisplayMember = "Display";
            shoppingCartListBox.ValueMember = "Display";
        }

        private void carInventoryListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void addCarBtn_Click(object sender, EventArgs e)
        {


            Car newCar = new Car();

            try
            {
                if (makeTextBox.Text.Equals(""))
                {
                    throw new Exception("Make is required.");
                }
                else
                {
                    newCar.Make = makeTextBox.Text;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            try
            {
                if (modelTextBox.Text.Equals(""))
                {
                    throw new Exception("Model is required.");
                }
                else
                {
                    newCar.Model = modelTextBox.Text;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            try
            {
                if (Decimal.Parse(priceTextBox.Text) <= 0)
                {
                    throw new Exception("Price required greater than 0.");
                }
                else
                {
                    newCar.Price = Decimal.Parse(priceTextBox.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            try
            {

                if ((int.Parse(yearTextBox.Text) < 1945) || (int.Parse(yearTextBox.Text) > 2022))
                {
                    throw new Exception("Year required between 1945 and " + 2022 );
                }
                else
                {
                    newCar.Year = int.Parse(yearTextBox.Text);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            try
            {
                if (colorTextBox.Text.Equals(""))
                {
                    throw new Exception("Color is required.");
                }
                else
                {
                    newCar.Color = colorTextBox.Text;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            if (!newCar.Make.Equals("") && !newCar.Model.Equals("") && newCar.Price != 0 && newCar.Year != 0 && !newCar.Color.Equals(""))
            {
                store.CarList.Add(newCar);
                makeTextBox.Clear();
                modelTextBox.Clear();
                priceTextBox.Clear();
                yearTextBox.Clear();
                colorTextBox.Clear();

                carListBinding.ResetBindings(false);
            }




        }

        private void addToCartBtn_Click(object sender, EventArgs e)
        {
            store.ShoppingList.Add((Car)carInventoryListBox.SelectedItem);
            store.CarList.Remove((Car)carInventoryListBox.SelectedItem);

            carListBinding.ResetBindings(false);
            shoppingListBinding.ResetBindings(false);
        }

        private void checkoutBtn_Click(object sender, EventArgs e)
        {
            decimal total = store.checkout();
            cartTotalLabel.Text = "Cart Total: $" + total.ToString();
            shoppingListBinding.Clear();
        }
    }
}
